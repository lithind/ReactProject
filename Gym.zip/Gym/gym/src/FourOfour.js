import React, { Component } from 'react'

export default class FourOfour extends Component {
  render() {
    return (
      <div><center><h2>This site can’t be reachedCheck</h2>
      <h3>Check if there is a typo in hjcdhsdkjkndkjncsdpot.com.</h3>
      <h3>If spelling is correct, try running Windows Network Diagnostics.</h3>
      <h4>DNS_PROBE_FINISHED_NXDOMAIN</h4></center>
         </div>
    )
  }
}
