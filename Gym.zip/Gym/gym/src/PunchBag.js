import React, { Component } from 'react'

export default class PunchBag extends Component {
  render() {
    return (
      <div>PunchBag</div>
    )
  }
}
