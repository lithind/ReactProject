import React, { Component } from 'react'
import './Home.css'
import {Link} from 'react-router-dom'
import "bootstrap/dist/css/bootstrap.min.css";
import { Dropdown } from "react-bootstrap";
export default class Home extends Component {
  render() {
    return (
      <body>
        <div className='nav'>
        <div className='logo'></div>
        <div className='navoptions'>
            <Link to={"HomeBackground"} className="link"><label style={{marginLeft:200}} className='label2 underline'>Home</label></Link>
            <Dropdown style={{float:'right', marginTop:-8 ,marginLeft:10}}>
              <Dropdown.Toggle  variant='' id="dropdown-basic">
                <label className='label2 underline'>Product</label>
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item href="/Product/dumbell">dumbell</Dropdown.Item>
                <Dropdown.Item href="/Product/weightliftingbar">weightliftingbar</Dropdown.Item>
                <Dropdown.Item href="/Product/Bar">bar</Dropdown.Item>
                <Dropdown.Item href="/Product/punchbag">Punch bag</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
            {/* <Link to={"Service"} className="link"><label className='label2'>Service</label></Link> */}
            <Link to={"About"} className="link"><label className='label2 underline'>About</label></Link>
            <Link to={"/Contact"} className="link"><label className='label2 underline'>Contact</label></Link>
            {/* <Link to={"Profile/:id"} className="link"><label className='label2'>Profile</label></Link> */}

        </div>
        <div className='login'>
        <Link to={"Login"} className="link"><label className='label2 underline'>Login</label></Link>
        </div>
        </div>
       
      </body>
    )
  }
}
