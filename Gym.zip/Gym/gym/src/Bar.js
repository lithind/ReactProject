import React, { Component } from 'react'

export default class Bar extends Component {
  render() {
    return (
      <div>

        
      </div>
    )
  }
}
