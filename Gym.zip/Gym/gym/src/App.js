import './App.css';
import Home from './Home';
import Contact from './Contact';
import About from './About';
import HomeBackground from './HomeBackground';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import FourOfour from './FourOfour';
import Dumbell from './Dumbell';
import Bar from './Bar';
import Weightliftingbar from './Weightliftingbar';
import PunchBag from './PunchBag';
import Login from './Login';
import Userhome from './Userhome';
import CartFromPublic from './CartFromPublic';
import UserhomeBackground from './UserhomeBackground'
import Cart from './Cart';
import SignUp from './SignUp';
import PlaceOrder from './PlaceOrder';
import MyOrders from './MyOrders'
import Footer from './Footer';


function App() {
  const status=localStorage.getItem("status")
  return (
    <div>
      <BrowserRouter>
      {
      status!=1?
      <Home/>:<Userhome/>}
      <Routes>
        <Route path="/"  element={<HomeBackground/>}></Route>
        <Route path="HomeBackground"  element={<HomeBackground/>}></Route>
        <Route path="/Contact" element={<Contact/>}></Route>
        <Route path="/Product/*" >
          <Route path="Dumbell" element={<Dumbell/>}></Route>
          <Route path="weightliftingbar" element={<Weightliftingbar/>}></Route>
          <Route path="Bar" element={<Bar/>}></Route>
          <Route path="punchbag" element={<PunchBag/>}></Route> 
        </Route>
        <Route path="About" element={<About/>}></Route>
        <Route path='/*' element={<FourOfour/>}></Route>
        <Route path='/Login' element={<Login/>}></Route>
        <Route path='Userhome' element={<UserhomeBackground/>}></Route>
        <Route path="/UserhomeBackground" element={<UserhomeBackground/>}></Route>
        <Route path="Cart" element={<Cart/>}></Route>
        <Route path="/SignUp" element={<SignUp/>}></Route>
        <Route path='cart/PlaceOrder' element={<PlaceOrder/>}></Route>
        <Route path='/CartFromPublic' element={<CartFromPublic/>}></Route>
        <Route path='/MyOrders' element={<MyOrders/>}></Route>

      </Routes>
      </BrowserRouter>
      
    </div>
  );
}
export default App;
