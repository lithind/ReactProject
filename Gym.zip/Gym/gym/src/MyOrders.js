import React, { Component } from 'react'
import json from './db.json'
import * as icons from 'react-icons/ai'
import './MyOrders.css'
import axios from 'axios'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Footer from './Footer'



export default class MyOrders extends Component {

    constructor(props)
    {
        super(props)
        this.state={
            loginId:localStorage.getItem("loginId")
        }
    }
    cancelOrder(item)
    {
      console.log(item.id);
      axios.delete('http://localhost:3000/order/'+item.id)
      toast.warning("Order cancelled")


     
    }


  render() {
    return (
      <div>
      <div style={{width:"900px",marginLeft:"100px",marginTop:"30px",paddingTop:"20px",paddingBottom:"20px",paddingLeft:"10px",paddingRight:"10px"}}>
        <div className='orderheading'>
        <center><h1 style={{fontFamily:"inconsolata,monospace",fontWeight:"bold"}}>MY ORDERS</h1><hr></hr></center>
        </div>
        {
            json.order.map((item)=>{
                return(
                  
                this.state.loginId==item.loginid?
                <div className='viewitems'>
                <div className='image'>
                  <img src={item.image} style={{height:"200px",width:"70%" }} className='imagehov'></img>
                </div>

                <div className='details'>
                <h3 style={{fontFamily:"inconsolata,monospace",marginLeft:"10px"}} > {item.Productname}</h3>
                <h5 style={{fontFamily:"inconsolata,monospace",marginLeft:"10px"}} >Qt :{item.quantity} item</h5><br></br>
                <h3 style={{fontFamily:"inconsolata,monospace",marginLeft:"10px"}} >${item.price}</h3><br></br>
                <span style={{fontFamily:"inconsolata,monospace",marginLeft:"10px"}} >Tracking Status on: 11:30pm, Today</span><br></br>
                <br></br>
                <button className='button1'  onClick={()=>this.cancelOrder(item)}> Cancel Order</button>
                <hr></hr>
                </div>
                
            </div>:""
              
            )})
        }

        
                    <ToastContainer position="top-right"/>

      </div>
      <Footer></Footer>
      </div>
    )
  }
}
