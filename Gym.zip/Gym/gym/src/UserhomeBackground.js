import React, { Component } from 'react'
import Footer from './Footer'
import './UserhomeBackground.css'
export default class UserhomeBackground extends Component {
  render() {
    return (
      <div>
        <div className='back1'>
        <div className='content'>
        <div className='fonthover'>
        <h3 style={{color:"white",fontSize:30,fontFamily:"inconsolata,monospace" ,fontWeight:"bold"}}>MAKE YOUR TODAY<br></br><span style={{color:"#1093ff"}}> BETTER THAN</span> <span>YESTERDAY</span></h3>
        </div>
        <hr style={{ border: "5px solid white", width:"40%"}}></hr>
        <span style={{color:"white",fontSize:"12px",fontFamily:"inconsolata,monospace"}}>we provides high quality with affordable prices for you to make your home loke a gum room</span>
        </div>
      </div>
      <Footer></Footer>
      </div>
    
      
    )
  }
}
