import React, { Component } from 'react'
import json from './db.json'
import * as icon from 'react-icons/hi'
import Footer from './Footer';
import './HomeBackground.css';
import a from'./images/a.png'
import b from'./images/b.png'
import c from'./images/c.png'
import d from'./images/d.png'
import e from'./images/e.png'
import f from'./images/f.png'
import g from'./images/g.png'
import h from'./images/h.png'
import i from'./images/i.png'
import j from'./images/j.png'



export default class HomeBackground extends Component {
  render() {
    return (
      <div>
        <div className='back'>
          <div className='insideback'>
          </div>
        </div>
          <div class="slider">
            <div class="slide-track">
              <div class="slide">
                <img src={a} width="200px" alt="" />
              </div>
              <div class="slide">
                <img src={b}  alt="" />
              </div>
              <div class="slide">
                <img src={c}  alt="" />
              </div>
              <div class="slide">
                <img src={d} alt="" />
              </div>
              <div class="slide">
                <img src={e}  alt="" />
              </div>
              <div class="slide">
                <img src={f}  alt="" />
              </div>
              <div class="slide">
                <img src={g}  alt="" />
              </div>
              <div class="slide">
                <img  src={h}  alt="" />
              </div>
              <div class="slide">
                <img src={i}   alt="" />
              </div>
              <div class="slide">
                <img src={j}  alt="" />
              </div>

              

            </div>
          </div>

          
          <div className='popular1'>
            <div className='popular2'>
            <center><span style={{fontFamily:"inconsolata,monospace",fontSize:"25px",fontWeight:"bold",color:"black" }}>POPULAR PRODUCTS IN STORE</span></center>
            <hr style={{color:"black"}}></hr>
            <span style={{fontFamily:"inconsolata,monospace",fontSize:"11.5px",color:"black" ,marginLeft:"15px" }}>These pieces have proven time and time again to be the best sellers of the season, take a look at these and more in our wide selection of used gym equipment
            </span>
            
             { json.populer.map((item)=>
              {
                return(
                  
                 <div className='display'> 
                
                <div className='maincard1'>
                  <div style={{height:"220px",backgroundColor:"blue"}}>
                    <img src={item.image} style={{height:"220px",width:"210px"}}></img>
                  </div>
                <div >
                  <br></br>
                  <center><icon.HiStar ></icon.HiStar>&nbsp;<icon.HiStar ></icon.HiStar>&nbsp;<icon.HiStar ></icon.HiStar>&nbsp;<icon.HiStar ></icon.HiStar>&nbsp;<icon.HiStar ></icon.HiStar><br></br>
                    <span style={{fontFamily:"inconsolata,monospace",fontWeight:"bold",fontSize:"15px"}}>{item.name}</span><br></br>
                    <span style={{fontFamily:"inconsolata,monospace",fontSize:"15px",color:"#1093ff"}}>Price $ {item.price}</span></center>
                </div>

                </div>
                </div>
                )
                
              })}

            </div>
             
          </div>
          <div className='popular1image'>
            
              <div className='lefttop'>

              </div>

              <div className='leftbottom'>
              </div>
            

            
              <div className='right'>

              </div>
          

          </div>


          <div >
          <Footer></Footer>
          </div>
        
      </div>
      
    )
  }
}
