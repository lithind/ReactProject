import React, { Component } from 'react'
import './Dumbell.css'
import Product from './db.json'
import Footer from './Footer';
import * as icon from 'react-icons/bs'


export default class Dumbell extends Component {

  constructor(props){
    super(props)
  }
  addtocart(event){
    console.log(event.target.id);
    localStorage.setItem("productId",event.target.id)
    if(localStorage.getItem("status")=="1")
    {
      // console.log("hiii")
      window.location.href="/CartFromPublic"
    }
    else{
    window.location.href="/Login"
    }
    // 
    
  }
 
  render() {
    return (
      <div>
      <div className='maincard'>
      {Product.products.map((item)=>{
        return (<div className='card'>
          <div className='img1'>
            
          <img style={{height:"200px" ,width:"200px"}}  src={item.image}></img>

          </div>
        <icon.BsStar  ></icon.BsStar>&nbsp;<icon.BsStar ></icon.BsStar>&nbsp;<icon.BsStar ></icon.BsStar>&nbsp;<icon.BsStar ></icon.BsStar>&nbsp;<icon.BsStar ></icon.BsStar><br></br><br></br>
          <div className='cardinside'>
            <span style={{fontFamily:"inconsolata,monospace"}}>{item.name}</span><br></br>
            <span  style={{color:"#1093ff",fontWeight:"bold"}}>Price:${item.price}</span><br></br>
            <div className='Buy'>
              <button id={item.id} style={{fontFamily:"inconsolata,monospace"}} className='Button1' onClick={(e)=>this.addtocart(e)}>ADD TO CART</button>
            </div>
          </div>
        </div> )  
      })}
      </div> 
      <Footer></Footer>
      </div> 
    )
  }
}
