
import React, { Component } from 'react'
import LoginData from './db.json'
import './Login.css';
import axios from 'axios'
import Dumbell from './Dumbell';
import HomeBackground from './HomeBackground';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Footer from './Footer';

export default class Login extends Component {
    constructor(props){ 
        super(props);
        this.state={
            name:"",
            password:""
        }
    }
    changeName(event){
        this.setState({
            name:event.target.value,
        })
    }
    changePass(event){
        this.setState({
            password:event.target.value
        })
    }
    success(){
        console.log("hello");
        window.location.href="HomeBackground"
    }
    toSignupPage()

{
    console.log("hello");
    window.location.href="SignUp"
}

    register(){

       
   
        axios({
  
          method:'post',
  
          url:'http://localhost:3000/registration',
  
          data:{
  
            name:this.state.name,
  
            password:this.state.password,


          }
        }).catch((error)=>
  
        {
  
            console.log("Unable to Connect");
  
        })
        // window.location.href="/HomeBackground"
        window.location.reload()
    }
    //  notify = () => toast("Successfully Login")


count(){
    
           

    LoginData.cart.map((item)=>{
    if(item.loginid==localStorage.getItem("loginId"))
    {
        var totalAmount=localStorage.getItem("totalAmount")
        totalAmount=parseInt(totalAmount)
        totalAmount=totalAmount+item.totalprice
        totalAmount=totalAmount.toString()
        localStorage.setItem("totalAmount",totalAmount)

      var cart=localStorage.getItem("cartCount");
      cart=parseInt(cart)
      cart=cart+1
      cart=cart.toString()
      localStorage.setItem("cartCount",cart)
    }
  })
}

     loginValidation (){
        const username = this.state.name;
        const pass = this.state.password;
        
        const login=LoginData.registration.find((item)=>item.name==username)
        if(login)
        {
            localStorage.setItem("loginId",login.id)
            localStorage.setItem("status","1")
            localStorage.setItem("cartCount","0")
            localStorage.setItem("totalAmount","0")
            if(login.password==pass)
            {
                toast.success("Successfully Logined")
                this.count()
                setTimeout(() => {
                     if(localStorage.getItem("productId")!=null)
                     {
                        window.location.href="/cartFromPublic"
                    }
                else{
                                    

                window.location.href="Userhome"
                }
                },2000);
               
                

            }
            else{
                alert("Incorrect Password")
            }
        }
        else{
            alert("incorrect Username")
        }

        
    }
//  changecolor()
//  {
//     document.getElementById("1").style.color="blue";
//     document.getElementById("1").style.backgroundColor="red"
//  }
//  changecolor1()
//  {
//         document.getElementById("1").style.color="white"

//  }

  render() {
    return (
            <div>
            <div className='Background-image'>
                <br/>
               <div className='login1'>
                <br></br>
                <h2 >Log in to your account</h2><br></br>
                <span style={{marginRight:"30px",letterSpacing:1.5}}>Username   </span><input className='input' type="text" value={this.state.name} onChange={(event)=>this.changeName(event)}></input>
                {/* {console.log(this.state.name)} */}
                <br></br><br></br><br></br>
                <span  style={{marginRight:"30px" ,letterSpacing:1.5}}>Password </span><input className='input' type="Password" value={this.state.password} onChange={(event)=>this.changePass(event)}></input>
                {/* {console.log(this.state.name)}
                {console.log(this.state.password)} */}
                {/* {console.log(LoginData)} */}
                <br></br>
                <br></br>
                <br></br>
                <button type="submit" onClick={()=>this.loginValidation()} >Login</button>
                <br></br><br></br>
               <div style={{display:"flex",justifyContent:"center"}}>
               <label style={{color:"white",fontSize:"20px"}} >Create Account   </label>                
               <label className='Forhover'   onClick={()=>this.toSignupPage()} id="1">SignUp</label>
                </div>
               </div>
                    <ToastContainer position="top-right"/>

            </div>
            <Footer></Footer>
            </div>
    )

  }
}

