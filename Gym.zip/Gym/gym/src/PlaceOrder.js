import React, { Component } from 'react'
import './PlaceOrder.css'
import json from './db.json'
import axios from 'axios'
import Footer from './Footer'

export default class PlaceOrder extends Component {

constructor(props)
{
  super(props)
  this.state={
    name:'',
    phone:'',
    address:''

  }
}

order()
{
json.cart.map((item)=>{
  if(item.loginid==localStorage.getItem("loginId"))
  {
    console.log("started");
    axios({
      method:"post",
      url:'http://localhost:3000/order',
      data:
      { cartid:item.id,
        productId:item.productId,
        Productname:item.Productname,
        price:item.price,
        image:item.image,
        loginid:item.loginid,
        quantity:item.quantity,
        totalprice:item.totalprice,

      }
    }).catch((error)=>console.log(error))
      
    axios.delete('http://localhost:3000/cart/'+item.id)
    localStorage.setItem("cartCount","0")
    localStorage.setItem("totalAmount","0")


  }
})
}
  
  render() {
    return (
      <div>
      <div style={{backgroundColor:"black",paddingTop:"30px",paddingBottom:"30px"}}>
        <div className='address'>
          <br></br>
          <center><h3 style={{color:"white"}}>Shipping Details</h3></center><br></br>
          <form >
          <h5 style={{color:"white",paddingLeft:"20px"}}>1.Name</h5>
          <span style={{color:"red",paddingLeft:"20px"}}>Start with Capital letter</span>
          <input type="text" style={{width:"800px",borderRadius:"20px",backgroundColor:"grey",marginLeft:"20px",paddingLeft:"20px",color:"white"}} pattern="[A-Z][a-z]*" required></input><br></br><br></br>
          <h5 style={{color:"white",paddingLeft:"20px"}}>2.Phone Number</h5>
          <span style={{color:"red",paddingLeft:"20px"}}>10 Digit start with 7/8/9</span>

          <input type="text" style={{width:"800px",height:"30px",borderRadius:"20px",backgroundColor:"grey",marginLeft:"20px",paddingLeft:"20px",color:"white"}} pattern="[789][0-9]{9}" required></input><br></br><br></br>
          <h5 style={{color:"white",paddingLeft:"20px"}}>3.Address Line</h5>
          <input type="text" style={{width:"800px",height:"70px",borderRadius:"20px",backgroundColor:"grey",marginLeft:"20px",paddingLeft:"20px",color:"white"}} pattern="[A-Za-z0-9]+" required></input>
          <br></br><br></br>
          <center><button onClick={()=>this.order()}>Order</button></center>
         </form>
        </div>
      </div>
      <Footer></Footer>
      </div>
    )
  }
}
