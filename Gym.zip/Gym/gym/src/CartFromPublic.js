import React, { Component } from 'react'
import json from './db.json'
import './cartFromPublic.css'
import { PageItem } from 'react-bootstrap'
import axios from 'axios'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Footer from './Footer'
export default class CartFromPublic extends Component {
    constructor(props){
        super(props)
        this.state={
            loginid:localStorage.getItem("loginId"),
            productid:localStorage.getItem("productId")

        }
    }

count(){
    localStorage.setItem("cartCount","1")  
    json.cart.map((item)=>{
    if(item.loginid==localStorage.getItem("loginId"))
    {
      var cart=localStorage.getItem("cartCount");
      cart=parseInt(cart)
      cart=cart+1
      cart=cart.toString()
      localStorage.setItem("cartCount",cart)
    }
    
  })
}




addtocart2(item)
{
  console.log(item);
  axios({
  method:"post",
  url:'http://localhost:3000/cart',
  data:{

  "Productname":item.name,
  "price":item.price,
  "image":item.image,
  "loginid":this.state.loginid,
  "productId":this.state.productid,
  "quantity":1,
  "totalprice":item.price * 1

  } 
}
  ).catch((error)=>console.log(error))
this.count()
toast.success("Added to Cart")

setTimeout(() => {
                     
        window.location.href="/UserhomeBackground"

                },2000);

}

  render() {
    return (
      <div>
    <div className='lid'>
      <div className='maincard'>
        {   
        json.products.map((item)=>{
        return(
        <div>
            {this.state.productid==item.id?
            <div className='card1'>
                <div className='cardinside'>
                    <img className='img' src={item.image}></img>
                </div>
            </div> :""}
        </div>)
        })   
        }
      </div>

        <div className='Description'>
          {
            json.products.map((item)=>{
              return(
                this.state.productid==item.id?
                <div>
                  <h1 style={{fontFamily:"inconsolata,monospace"}} > {item.name}</h1>
                  <h2 style={{color:"#1093ff",fontFamily:"inconsolata,monospace"}}>Price : $ {item.price}</h2>
                  <h4 style={{fontFamily:"inconsolata,monospace",fontSize:20,textAlign:'justify'}}>{item.description}</h4>
                  <button style={{color:"black" ,marginLeft:300,marginTop:"20px",border:"solid 1px grey"}}   onClick={()=>this.addtocart2(item)}>Add to Cart</button>
                </div>:""
                
              )
            })
          }
            
        </div>
                    <ToastContainer position="top-right"/>

    </div>
    <Footer></Footer>
    </div>
    )
  }
}
