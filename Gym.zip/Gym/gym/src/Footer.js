import React, { Component } from 'react'
import './Footer.css'
import * as icons from 'react-icons/fa'
import * as iconss from 'react-icons/ai'
import * as iconsss from 'react-icons/fi'
import * as iconssss from 'react-icons/im'





export default class Footer extends Component {
  render() {
    return (
    <div>
        <div className='footer'>

            <div className='a'>
                <span style={{fontFamily:"inconsolata,monospace",fontSize:"20px",fontWeight:"bold"  }}>KEEP IN TOUCH</span><br></br><br></br>
                <span style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>25th floor Palace Building</span><br></br>
                <span style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>221b Baker street Any Town - London</span><br></br>
                <span style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>United Kingdom</span><br></br><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>(+01). 234. 567.890</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>demo@demo.com</span><br></br>

            </div>

            <div className='b'>
                <span style={{fontFamily:"inconsolata,monospace",fontSize:"20px",fontWeight:"bold"  }} >ABOUT US</span><br></br><br></br>
                <span className="hoverr"  style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }} >About Us</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Career</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Services</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Contact</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>F.A.Qs</span><br></br>

            </div>

            <div className='c'>
                <span  style={{fontFamily:"inconsolata,monospace",fontSize:"20px",fontWeight:"bold"  }}>SHOPPING</span><br></br><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>New arrivals</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Best sellers</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Featured items</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>On sale</span><br></br>
            </div>

            <div className='d'>
                <span  style={{fontFamily:"inconsolata,monospace",fontSize:"20px",fontWeight:"bold"  }}>SUPPORT</span><br></br><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Shopping guide</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Contact us</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Terms & conditions</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>Shipping & return</span><br></br>
                <span className="hoverr" style={{fontFamily:"inconsolata,monospace",fontSize:"14px" }}>F.A.Qs</span><br></br>
            </div>

        </div>
        <div className='copyright'>
            <div className='copy'>
                <iconss.AiOutlineCopyrightCircle style={{color:"white"}}></iconss.AiOutlineCopyrightCircle>&nbsp;
                <span style={{fontFamily:"inconsolata,monospace",fontSize:"14px" ,color:"white"}}>Copyright Ryde Enterprises LLC 2021</span>   
            </div>

            <div className='icons'>
                <icons.FaFacebookF style={{color:"white"}}></icons.FaFacebookF>&nbsp;&nbsp;
                <iconss.AiOutlineTwitter style={{color:"white"}}></iconss.AiOutlineTwitter>&nbsp;&nbsp;
                <iconsss.FiInstagram style={{color:"white"}}></iconsss.FiInstagram>&nbsp;&nbsp;
                <iconssss.ImYoutube2 style={{color:"white"}}></iconssss.ImYoutube2>
            </div >
        

        </div>
    </div>
    
    )
  }
}
