import axios from 'axios'
import React, { Component } from 'react'
import './Cart.css'
import json from './db.json'
import * as icons from 'react-icons/ai'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Link } from 'react-router-dom'
import Footer from './Footer'


export default class Cart extends Component {

    constructor(props)
    {
        super(props)
        {
            this.state={

                loginId:localStorage.getItem("loginId")
            }
        }
    }

    count()
    {
        console.log(localStorage.getItem("cartCount"));      
        var cart=localStorage.getItem("cartCount");
        cart=parseInt(cart)
        cart=cart-1
        cart=cart.toString()
        localStorage.setItem("cartCount",cart)
        // console.log(localStorage.getItem("cartCount"));

    }
    delete(item)
    {
        const id=item.id
        // console.log(id);
        axios.delete('http://localhost:3000/cart/'+id)
        this.count()
        toast.success("Deleted Successfully")
        setTimeout(() => {
                     
        // window.location.href="/Cart"

                },2000);

    }
    calculateTotalSum()
    {
        localStorage.setItem("totalAmount","0")
        var total=0
       json.cart.map((item)=>
       {
        // console.log("hjhjh : ",item.quantity ,item.price,item.totalprice);
        if(item.loginid==this.state.loginId)
        {
            total=item.totalprice+total+item.price
            
        }
        localStorage.setItem("totalAmount",total)
        console.log(total);
        // console.log(localStorage.getItem("totalAmount"))
       })

    }

    addsub(e,f,item)
    {
        axios({
            method:'patch',
            url:'http://localhost:3000/cart/'+f,
            data:{
                "price":item.price,
                "quantity":e,
                "totalprice":e*item.price
                }
            }).catch((error)=>console.log(error))
            this.calculateTotalSum()


    }
    add(item)
    {
        
             this.addsub(item.quantity=item.quantity+1,item.id,item)
           
    }
    substract(item)
    {
            if(item.quantity>1)
            {
             this.addsub(item.quantity=item.quantity-1,item.id,item)
            }
    }
    

  render() {
    return (
        <div>
      <div className='main' >
        <div className='cartheading'>
        <h4 style={{fontFamily:"inconsolata,monospace",fontWeight:"bold"}}>SHOPPING CART</h4><hr></hr>

        {
            json.cart.map((item)=>{
            return(
                this.state.loginId===item.loginid?
                    <div className='cartdetails'>
                    <div className='div1'>
                        <img src={item.image} ></img>
                    </div>

                    <div className='div2'>
                        <h5 style={{fontFamily:"inconsolata,monospace",fontWeight:'bold'}}>{item.Productname}</h5>
                        <h4 style={{fontFamily:"inconsolata,monospace",color:"red"}}>${item.price}</h4>

                    </div>

                    <div className='div3'>
                    <table>
                        <tr >
                            <th rowSpan={2} style={{fontFamily:"inconsolata,monospace" ,paddingLeft:"20px"}}>{item.quantity}</th>
                            <td><button onClick={()=>this.add(item)} className='buttonplus'>+</button></td>
                        </tr>
                        <tr>    
                            <td><button onClick={()=>this.substract(item)} className='bottomminus'>-</button></td>
                        </tr>
                    </table>

                    </div>

                    <div className='div4'>
                        <h5 style={{fontFamily:"inconsolata,monospace",color:"black",paddingTop:"25px",paddingLeft:"1px"}}>$ {item.totalprice}</h5>
                        <icons.AiFillDelete onClick={()=>this.delete(item)} style={{fontSize:"25px",marginLeft:"100px",marginTop:"20px"}}></icons.AiFillDelete>


                    </div>

                    </div>:""
            )
            })
        }
        </div>

        <div className='totalprice' style={{ fontFamily: "inconsolata ,monospace"}}>
            <div className='div5'style={{display:"flex",justifyContent:"center",alignItems:"center"}}>
                <h6>{localStorage.getItem("cartCount")} Items</h6>
                <h6 style={{paddingLeft:"290px"}}>$ {localStorage.getItem("totalAmount")}</h6>
            </div > 
                
            <div  className='div5' style={{display:"flex",justifyContent:"center",alignItems:"center",marginTop:"10px"}}>
                <h6>Shipping</h6>   
                <h6 style={{paddingLeft:"320px"}}><del>$5</del></h6>
            </div >

            <div style={{marginTop:"10px",height:"25px"}}>

            </div>

            <div className='div5'style={{display:"flex",justifyContent:"center",alignItems:"center",marginTop:"10px"}}>
                <h6>Total (tax excl.)</h6>
                <h6 style={{paddingLeft:"199px"}}>$ {localStorage.getItem("totalAmount")}</h6>
            </div > 

            <div className='div5'style={{display:"flex",justifyContent:"center",alignItems:"center",marginTop:"10px"}}>
                <h6>Total (tax incl.)</h6>
                <h6 style={{paddingLeft:"199px"}}>$ {localStorage.getItem("totalAmount")}</h6>
            </div >

             <div className='div5'style={{display:"flex",justifyContent:"center",alignItems:"center",marginTop:"10px"}}>
                <h6> Taxes:</h6>
                <h6 style={{paddingLeft:"303px"}}>$ 0.00</h6>
            </div >

        <div style={{marginTop:"35px",display:"flex",justifyContent:"center"}}>
               <Link to="PlaceOrder"><button style={{marginLeft:"3px",color:"black",border:"solid 1px grey"}}>Place Order</button></Link> 
        </div>

            <div>

            </div>

            
        </div>
        

                    <ToastContainer position="top-right"/>

      </div>
      <Footer></Footer>
      </div>
    )
  }
}
