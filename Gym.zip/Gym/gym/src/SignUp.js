import React, { Component } from 'react'
import LoginData from './db.json'
import './SignUp.css';
import axios from 'axios'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Footer from './Footer';
export default class SignUp extends Component {
    constructor(props){ 
        super(props);
        this.state={
            name:"",
            password:""
        }
    }
    changeName(event){
        this.setState({
            name:event.target.value,
        })
    }
    changePass(event){
        this.setState({
            password:event.target.value
        })
    }
    // success(){
    //     window.location.href="HomeBackground"
    // }

    register(){
        // alert(this.state.name,this.state.password)
        if(this.state.name=="" || this.state.name=="" && this.state.password=="" || this.state.password=="")
        {
        toast.error("Invalid Entry")
         setTimeout(() => {
                     
            window.location.href="/SignUp"

                },2000);

        }
        else
        {
            axios({
            method:'post',
            url:'http://localhost:3000/registration',
            data:{
            name:this.state.name,
            password:this.state.password,
                }
            }).catch((error)=>
    
            {
    
                console.log("Unable to Connect");
    
            })
            toast.success("Registered Successfully")

             setTimeout(() => {
                     
            window.location.href="/Login"

                },2000);

        }
       
    }
    //  notify = () => toast("Successfully Login")
  render() {
    return (
            <div>
            <div className='Background'>
                <br/>
               <div className='login1'>
                <br></br>
                <h2 >Create Account</h2><br></br>
                <span style={{marginRight:"30px",letterSpacing:1.5}}>Username   </span><input className='input' type="text" value={this.state.name} onChange={(event)=>this.changeName(event)}></input>
                <br></br><br></br><br></br>
                <span  style={{marginRight:"30px" ,letterSpacing:1.5}}>Password </span><input className='input' type="Password" value={this.state.password} onChange={(event)=>this.changePass(event)}></input>
                <br></br>
                <br></br>
                <br></br>
                <button type="submit" onClick={()=>this.register()} >Register</button>
               </div>
               
                    <ToastContainer position="top-right"/>
            </div>
            <Footer></Footer>
            </div>
    )

  }
}
