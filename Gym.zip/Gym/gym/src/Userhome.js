import React, { Component } from 'react'
import './Userhome.css'
import * as icons from 'react-icons/fi'
import {HiOutlineLogout} from 'react-icons/hi'
import {HiShoppingCart} from 'react-icons/hi'

import { Link } from 'react-router-dom'
import json from './db.json'
import { Dropdown } from "react-bootstrap";
import logout from './images/logout.png'

export default class Userhome extends Component {
constructor(props)
{
    super(props)
    this.state={
    
    loginId:localStorage.getItem("loginId")
    }
    
}


logout(){
    // localStorage.setItem("status","0")
    localStorage.clear()
    window.location.href="HomeBackground"
  }
    
  render() {
    // {this.count() }     

    return (
      <div>
      <div>  
        <div className='navbar'>
        <div className='logo'></div>
        <div className='navoptions'>
            <Link to="/UserhomeBackground"><label className='label2 underline'>Home</label></Link>
            <Dropdown style={{float:'right', marginTop:-8,paddingLeft:"10px"}}>
              <Dropdown.Toggle  variant='' id="dropdown-basic">
                <label className='label2 underline'>Product</label>
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item href="/Product/dumbell">dumbell</Dropdown.Item>
                <Dropdown.Item href="/Product/weightliftingbar">weightliftingbar</Dropdown.Item>
                <Dropdown.Item href="/Product/Bar">bar</Dropdown.Item>
                <Dropdown.Item href="/Product/punchbag">Punch bag</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
            <Link to="/MyOrders"><label className='label2 underline'>My Orders</label></Link>


        </div>                        

        
<div style={{marginLeft:"40px"}}>
        {json.registration.map((item)=>{
            return(<div >

                {item.id == this.state.loginId? <h1 className='tologout' style={{color:"white",fontSize:30,fontFamily:"inconsolata,monospace"}}>Welcome {item.name}</h1>: null }
          
                </div>)
                        
                    })
        }
</div>
<div style={{marginTop:"-6px",color:"white",border:"solid .5px grey"}}>
          {/* <button onClick={()=>this.logout()}  className="button">Logout </button>  */}
          <HiOutlineLogout onClick={()=>this.logout()}></HiOutlineLogout>
          {/* <img src={logout} style={{height:"30px",width:"30px"}} onClick={()=>this.logout()}></img> */}
</div>
        <div className='cart'>
          <span  style={{fontSize:"10px",backgroundColor:"red",borderRadius:"360px",padding:"2px",marginLeft:"15px",marginRight:"10px",paddingLeft:"3px",marginBottom:"-10px"}}>{localStorage.getItem("cartCount")}
          </span>
             <Link to="Cart"><HiShoppingCart style={{marginTop:"-19px"}} ></HiShoppingCart></Link>
        </div>
       
        </div>
      </div>
      </div>
    )
  }
}
