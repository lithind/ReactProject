import React, { Component } from 'react'
import './About.css'
import Footer from './Footer'
export default class About extends Component {
  render() {
    return (
      <div>
      <div className='BG'>
        <h1 style={{fontFamily:"inconsolata,monospace" ,textAlign:"center",paddingBottom:30,color:"black"}}> About us</h1>
        <div className='about'>
          <div className='column'   >
            <h4 style={{fontFamily:"inconsolata,monospace"}}>Our company</h4><br></br>
            <h6 style={{fontFamily:"inconsolata,monospace" ,fontWeight:"bolder"}}>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididun.</h6><br></br>

            <h6 style={{fontFamily:"inconsolata,monospace"}}>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dolor sit amet conse ctetur adipisicing elit.</h6>
          </div>
          <div className='column' >
            <h4 style={{fontFamily:"inconsolata,monospace"}}>Our team</h4>
            <h6 style={{fontFamily:"inconsolata,monospace" ,fontWeight:"bolder"}}>Lorem set sint occaecat cupidatat non</h6><br></br>
            <h6 style={{fontFamily:"inconsolata,monospace"}}>Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</h6>

          </div>
        </div>
        
      </div>
      <Footer></Footer>
      </div>
      
    )
  }
}
