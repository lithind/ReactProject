import React, { Component } from 'react'
import './Contact.css'
import * as icons from 'react-icons/hi'
import Footer from './Footer'
export default class Contact extends Component {
  render() {
    return (
      <div>
      <div className='contact'>

        <div className='con1 '>
          <h5   style={{fontFamily:"inconsolata,monospace"}}>Information</h5>
        <br></br>
          <icons.HiLocationMarker  ></icons.HiLocationMarker>
          <h5 style={{fontFamily:"inconsolata,monospace"}}>Kakkanad,Kerala</h5>
          <hr></hr>
        
          <icons.HiOutlineMail style={{fontSize:"70px"}}></icons.HiOutlineMail>
          <h5 style={{fontFamily:"inconsolata,monospace"}}>equipurgym81@gmail.com</h5>

        </div>
        <div className='con'>
          <h5 style={{fontFamily:"inconsolata,monospace" ,marginLeft:20,marginTop:10}}>CONTACT US</h5><br></br>
          <label style={{fontFamily:"inconsolata,monospace" ,marginLeft:20,marginTop:10,fontSize:15}}>Subject &nbsp;</label><input type="text" style={{width:400}}></input><br></br><br></br>
          <label style={{fontFamily:"inconsolata,monospace" ,marginLeft:20,marginTop:10,fontSize:15}}>Email &nbsp;&nbsp;&nbsp;</label><input type="text" style={{width:400 ,}}></input><br></br><br></br>
          <div className='formfield'>
          <label  style={{fontFamily:"inconsolata,monospace" ,marginLeft:20,marginTop:10,fontSize:15}}>Message &nbsp;</label><textarea style={{width:400 ,height:100}}></textarea><br></br>
          </div>
          <br></br>
          <center><button style={{fontFamily:"inconsolata,monospace" ,color:"white  ",border:"solid 1px",backgroundColor:"black",fontSize:"15px"}}>Sent</button></center>
        </div>

      </div>
      <Footer></Footer>
      </div>
    )
  }
}
