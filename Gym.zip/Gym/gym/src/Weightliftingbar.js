import React, { Component } from 'react'

export default class Weightliftingbar extends Component {
  render() {
    return (
      <div>weightliftingbar</div>
    )
  }
}
